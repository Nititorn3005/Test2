import { Navigate, Outlet, createFileRoute } from '@tanstack/react-router'

import { AppShell } from '@/components/app/shell'
import { useAppStore } from '@/lib/store'

export const Route = createFileRoute('/_app')({
  component: AppLayout,
})

function AppLayout() {
  const { currentUser } = useAppStore()
  if (!currentUser) return <Navigate to="/" replace />
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  )
}
