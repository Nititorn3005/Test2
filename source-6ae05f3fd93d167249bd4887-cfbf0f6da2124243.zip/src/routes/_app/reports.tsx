import * as React from 'react'
import { createFileRoute } from '@tanstack/react-router'
import { Download, FileBarChart, Printer } from 'lucide-react'

import { EmptyState, Field, JobNo, PageHeader, RoleGate, StatusBadge } from '@/components/app/shell'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { OPEN_STATUSES, STATUS_LABEL, STATUS_ORDER, TX_LABEL, fmtDateTime, type JobStatus } from '@/lib/domain'
import { useAppStore } from '@/lib/store'

export const Route = createFileRoute('/_app/reports')({
  head: () => ({ meta: [{ title: 'รายงาน · Hatyai Soundstar' }] }),
  component: () => (
    <RoleGate roles={['ADMIN']}>
      <Reports />
    </RoleGate>
  ),
})

type Kind = 'period' | 'open' | 'done' | 'stock'

function downloadCsv(name: string, rows: (string | number)[][]) {
  const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n')
  const url = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }))
  const a = Object.assign(document.createElement('a'), { href: url, download: name })
  a.click()
  URL.revokeObjectURL(url)
}

function Reports() {
  const { jobs, transactions, inventory, profiles, profileName } = useAppStore()
  const [kind, setKind] = React.useState<Kind>('period')
  const [from, setFrom] = React.useState('')
  const [to, setTo] = React.useState('')
  const [status, setStatus] = React.useState<JobStatus | ''>('')
  const [tech, setTech] = React.useState('')
  const inRange = (iso: string) => {
    const d = iso.slice(0, 10)
    return (!from || d >= from) && (!to || d <= to)
  }

  const jobRows = jobs.filter(
    (j) =>
      inRange(j.receivedAt) &&
      (!tech || j.technicianId === tech) &&
      (kind === 'open' ? OPEN_STATUSES.includes(j.status) : kind === 'done' ? j.status === 'COMPLETED' : !status || j.status === status),
  )
  const txRows = transactions.filter((t) => inRange(t.at))

  function exportCsv() {
    if (kind === 'stock') {
      downloadCsv('stock-movements.csv', [
        ['วันเวลา', 'ประเภท', 'รหัส', 'อะไหล่', 'จำนวน', 'คงเหลือ', 'ผู้ทำรายการ'],
        ...txRows.map((t) => {
          const i = inventory.find((x) => x.id === t.partId)
          return [fmtDateTime(t.at), TX_LABEL[t.type], i?.code ?? '', i?.name ?? '', t.qty, t.balanceAfter, profileName(t.by)]
        }),
      ])
    } else {
      downloadCsv(`repair-jobs-${kind}.csv`, [
        ['เลขที่ใบงาน', 'วันที่รับ', 'ลูกค้า', 'โทร', 'ยี่ห้อ', 'รุ่น', 'ช่าง', 'สถานะ'],
        ...jobRows.map((j) => [j.jobNo, fmtDateTime(j.receivedAt), j.customerName, j.phone, j.brand, j.model, profileName(j.technicianId), STATUS_LABEL[j.status]]),
      ])
    }
  }

  return (
    <>
      <PageHeader
        eyebrow="Reports"
        title="รายงาน"
        actions={
          <>
            <Button variant="outline" size="lg" onClick={exportCsv}><Download /> ส่งออก CSV</Button>
            <Button variant="outline" size="lg" onClick={() => window.print()}><Printer /> พิมพ์</Button>
          </>
        }
      />
      <Tabs value={kind} onValueChange={(v) => setKind(v as Kind)} className="no-print mb-4">
        <TabsList className="h-auto flex-wrap">
          <TabsTrigger value="period">งานซ่อมตามช่วงเวลา</TabsTrigger>
          <TabsTrigger value="open">งานค้าง</TabsTrigger>
          <TabsTrigger value="done">งานสำเร็จ</TabsTrigger>
          <TabsTrigger value="stock">การเคลื่อนไหวสต๊อก</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="no-print mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Field label="ตั้งแต่วันที่" htmlFor="r-from">
          <Input id="r-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-11 bg-card" />
        </Field>
        <Field label="ถึงวันที่" htmlFor="r-to">
          <Input id="r-to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-11 bg-card" />
        </Field>
        {kind === 'period' && (
          <Field label="สถานะ" htmlFor="r-status">
            <select id="r-status" className="native-select" value={status} onChange={(e) => setStatus(e.target.value as JobStatus | '')}>
              <option value="">ทุกสถานะ</option>
              {STATUS_ORDER.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
            </select>
          </Field>
        )}
        {kind !== 'stock' && (
          <Field label="ช่าง" htmlFor="r-tech">
            <select id="r-tech" className="native-select" value={tech} onChange={(e) => setTech(e.target.value)}>
              <option value="">ทุกคน</option>
              {profiles.filter((p) => p.role === 'TECH').map((p) => <option key={p.id} value={p.id}>{p.fullName}</option>)}
            </select>
          </Field>
        )}
      </div>

      <p className="mb-3 text-sm text-muted-foreground">
        พบ {kind === 'stock' ? txRows.length : jobRows.length} รายการ
      </p>

      {(kind === 'stock' ? txRows.length : jobRows.length) === 0 ? (
        <EmptyState icon={FileBarChart} title="ไม่มีข้อมูลในช่วงที่เลือก" />
      ) : kind === 'stock' ? (
        <div className="rounded-2xl border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>วันเวลา</TableHead><TableHead>ประเภท</TableHead><TableHead>อะไหล่</TableHead>
                <TableHead className="text-right">จำนวน</TableHead><TableHead className="text-right">คงเหลือ</TableHead><TableHead>ผู้ทำรายการ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {txRows.map((t) => (
                <TableRow key={t.id}>
                  <TableCell className="text-xs">{fmtDateTime(t.at)}</TableCell>
                  <TableCell>{TX_LABEL[t.type]}</TableCell>
                  <TableCell>{inventory.find((i) => i.id === t.partId)?.name}</TableCell>
                  <TableCell className="text-right font-ticket">{t.qty}</TableCell>
                  <TableCell className="text-right font-ticket">{t.balanceAfter}</TableCell>
                  <TableCell>{profileName(t.by)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <div className="rounded-2xl border border-border bg-card">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>เลขที่ใบงาน</TableHead><TableHead>วันที่รับ</TableHead><TableHead>ลูกค้า</TableHead>
                <TableHead>เครื่อง</TableHead><TableHead>ช่าง</TableHead><TableHead>สถานะ</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {jobRows.map((j) => (
                <TableRow key={j.id}>
                  <TableCell><JobNo>{j.jobNo}</JobNo></TableCell>
                  <TableCell className="text-xs">{fmtDateTime(j.receivedAt)}</TableCell>
                  <TableCell>{j.customerName}</TableCell>
                  <TableCell>{j.brand} {j.model}</TableCell>
                  <TableCell>{profileName(j.technicianId)}</TableCell>
                  <TableCell><StatusBadge status={j.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </>
  )
}
