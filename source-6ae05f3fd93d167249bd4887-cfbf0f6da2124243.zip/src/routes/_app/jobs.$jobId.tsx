import * as React from 'react'
import { Link, createFileRoute } from '@tanstack/react-router'
import {
  ArrowLeft,
  ArrowRightLeft,
  Camera,
  FileSearch,
  PackageMinus,
  Printer,
  Save,
} from 'lucide-react'
import { toast } from 'sonner'

import { EmptyState, Field, JobNo, Panel, StatusBadge } from '@/components/app/shell'
import { Button } from '@/components/ui/button'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  STATUS_LABEL,
  URGENCY_LABEL,
  allowedNextStatuses,
  fmtDateTime,
  isOverdue,
  type JobStatus,
  type RepairJob,
} from '@/lib/domain'
import { useAppStore } from '@/lib/store'
import { cn } from '@/lib/utils'

export const Route = createFileRoute('/_app/jobs/$jobId')({
  head: () => ({ meta: [{ title: 'รายละเอียดงานซ่อม · Hatyai Soundstar' }] }),
  component: JobDetail,
})

function JobDetail() {
  const { jobId } = Route.useParams()
  const { jobs, currentUser } = useAppStore()
  const job = jobs.find((j) => j.id === jobId)
  const canSee =
    job && (currentUser?.role !== 'TECH' || job.technicianId === currentUser.id)

  if (!job || !canSee) {
    return (
      <EmptyState
        icon={FileSearch}
        title="ไม่พบใบงาน"
        description="ใบงานนี้อาจไม่มีอยู่ หรือคุณไม่มีสิทธิ์เข้าถึง"
        action={
          <Button asChild variant="outline">
            <Link to="/jobs">กลับรายการงานซ่อม</Link>
          </Button>
        }
      />
    )
  }
  return <JobView job={job} />
}

function JobView({ job }: { job: RepairJob }) {
  const { currentUser, profileName, inventory, company } = useAppStore()
  const role = currentUser!.role
  const [statusOpen, setStatusOpen] = React.useState(false)
  const [partOpen, setPartOpen] = React.useState(false)
  const next = allowedNextStatuses(job.status, role)
  const canWork = role === 'ADMIN' || (role === 'TECH' && job.technicianId === currentUser!.id)
  const closed = job.status === 'COMPLETED' || job.status === 'CANCELLED'

  return (
    <>
      {/* Print-only header for the A4 job sheet */}
      <div className="hidden border-b-2 border-foreground pb-3 print:block">
        <p className="text-lg font-bold">{company.nameTh}</p>
        <p className="text-xs">{company.nameEn} · {company.address} · โทร {company.phones}</p>
        <p className="mt-2 text-base font-bold">ใบงานซ่อม / Service Job Sheet</p>
      </div>

      <div className="no-print mb-4">
        <Link to="/jobs" className="inline-flex min-h-11 items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="size-4" /> รายการงานซ่อม
        </Link>
      </div>

      <div className="ticket-edge relative mb-6 overflow-hidden rounded-2xl bg-sidebar p-5 text-sidebar-accent-foreground sm:p-6 print:bg-transparent print:p-0 print:text-foreground">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div>
            <p className="font-ticket text-2xl font-bold tracking-wide text-sidebar-primary print:text-foreground">{job.jobNo}</p>
            <h1 className="mt-1 font-display text-2xl font-bold">{job.customerName}</h1>
            <p className="text-sm text-sidebar-foreground/80 print:text-foreground">
              รับแจ้ง {fmtDateTime(job.receivedAt)} · โดย {profileName(job.receivedBy)}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <StatusBadge status={job.status} className="px-3 py-1 text-sm" />
            <span className={cn('rounded-full px-3 py-1 text-sm', job.urgency === 'URGENT' || job.urgency === 'HIGH' ? 'bg-destructive text-white' : 'bg-sidebar-accent')}>
              {URGENCY_LABEL[job.urgency]}
            </span>
          </div>
        </div>
        <div className="no-print mt-5 flex flex-wrap gap-2">
          {next.length > 0 && (canWork || role === 'FRONT') ? (
            <Button onClick={() => setStatusOpen(true)} className="bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90">
              <ArrowRightLeft /> เปลี่ยนสถานะ
            </Button>
          ) : null}
          {canWork && !closed && role !== 'FRONT' && (
            <Button variant="secondary" onClick={() => setPartOpen(true)}>
              <PackageMinus /> เบิกอะไหล่
            </Button>
          )}
          <Button variant="secondary" onClick={() => window.print()}>
            <Printer /> พิมพ์ / PDF (A4)
          </Button>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr] print:grid-cols-2">
        <div className="grid gap-6">
          <Panel title="ข้อมูลลูกค้าและเครื่อง">
            <dl className="grid gap-x-6 gap-y-3 text-sm sm:grid-cols-2">
              <Item label="เบอร์โทรศัพท์" value={<a href={`tel:${job.phone}`} className="font-ticket text-primary hover:underline">{job.phone}</a>} />
              <Item label="ผู้ติดต่อ" value={job.contactName} />
              <Item label="ที่อยู่ / สถานที่ติดตั้ง" value={job.address} wide />
              <Item label="ประเภทเครื่อง" value={job.machineType} />
              <Item label="ยี่ห้อ / รุ่น" value={`${job.brand} ${job.model}`} />
              <Item label="หมายเลขเครื่อง" value={job.serialNo && <span className="font-ticket">{job.serialNo}</span>} />
              <Item label="วันที่นัดหมาย" value={<span className={cn(isOverdue(job) && 'font-semibold text-destructive')}>{fmtDateTime(job.appointmentAt)}{isOverdue(job) && ' (เกินนัด)'}</span>} />
              <Item label="อาการเสีย" value={job.symptom} wide />
              <Item label="รายละเอียดเพิ่มเติม" value={job.details} wide />
              <Item label="หมายเหตุ" value={job.note} wide />
            </dl>
            {job.photos > 0 && (
              <p className="no-print mt-4 flex items-center gap-2 rounded-lg bg-secondary/60 px-3 py-2 text-xs text-muted-foreground">
                <Camera className="size-4" /> รูปภาพประกอบ {job.photos} รูป
              </p>
            )}
          </Panel>

          <RepairNotes job={job} editable={canWork && !closed} />

          <Panel title="อะไหล่ที่ใช้">
            {job.parts.length === 0 ? (
              <p className="text-sm text-muted-foreground">ยังไม่มีการเบิกอะไหล่สำหรับงานนี้</p>
            ) : (
              <ul className="divide-y divide-border text-sm">
                {job.parts.map((p, i) => {
                  const item = inventory.find((x) => x.id === p.partId)
                  return (
                    <li key={i} className="flex items-center justify-between gap-3 py-2">
                      <div>
                        <p className="font-medium">{item?.name}</p>
                        <p className="font-ticket text-[11px] text-muted-foreground">{item?.code} · {fmtDateTime(p.at)} · {profileName(p.by)}</p>
                      </div>
                      <span className="font-ticket">× {p.qty} {item?.unit}</span>
                    </li>
                  )
                })}
              </ul>
            )}
          </Panel>
        </div>

        <div className="grid h-fit gap-6">
          <AssignPanel job={job} />
          <Panel title="ประวัติการทำงาน">
            <ol className="relative ml-2 border-l-2 border-border">
              {[...job.history].reverse().map((h, i) => (
                <li key={h.id} className="relative pb-5 pl-5 last:pb-0">
                  <span className={cn('absolute -left-[7px] top-1 size-3 rounded-full ring-4 ring-card', i === 0 ? 'bg-highlight' : 'bg-border')} />
                  <p className="text-sm font-medium">
                    {h.from ? <>{STATUS_LABEL[h.from]} → </> : null}
                    {STATUS_LABEL[h.to]}
                  </p>
                  <p className="text-xs text-muted-foreground">{fmtDateTime(h.at)} · {profileName(h.by)}</p>
                  {h.note && <p className="mt-1 rounded-md bg-muted px-2 py-1 text-xs">{h.note}</p>}
                </li>
              ))}
            </ol>
          </Panel>
        </div>
      </div>

      <div className="mt-12 hidden grid-cols-3 gap-8 text-center text-xs print:grid">
        {['ลูกค้า', 'ช่างผู้ซ่อม', 'ผู้ตรวจรับ'].map((s) => (
          <div key={s}><div className="mb-1 border-b border-foreground pt-10" />{s}</div>
        ))}
      </div>

      <StatusDialog job={job} options={next} open={statusOpen} onOpenChange={setStatusOpen} />
      <IssuePartDialog job={job} open={partOpen} onOpenChange={setPartOpen} />
    </>
  )
}

function Item({ label, value, wide }: { label: string; value?: React.ReactNode; wide?: boolean }) {
  return (
    <div className={cn(wide && 'sm:col-span-2')}>
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="mt-0.5">{value || '—'}</dd>
    </div>
  )
}

function RepairNotes({ job, editable }: { job: RepairJob; editable: boolean }) {
  const { updateJob } = useAppStore()
  return (
    <Panel title="ผลการตรวจสอบและการซ่อม">
      <form
        className="grid gap-4"
        onSubmit={(e) => {
          e.preventDefault()
          const f = new FormData(e.currentTarget)
          const res = updateJob(job.id, {
            diagnosis: String(f.get('diagnosis')),
            resolution: String(f.get('resolution')),
            result: String(f.get('result')),
          })
          if (res.ok) toast.success('บันทึกผลการซ่อมแล้ว')
          else toast.error(res.error)
        }}
      >
        {([
          ['diagnosis', 'ผลการตรวจสอบ', job.diagnosis],
          ['resolution', 'วิธีแก้ไข', job.resolution],
          ['result', 'ผลการซ่อม', job.result],
        ] as const).map(([name, label, value]) =>
          editable ? (
            <Field key={name} label={label} htmlFor={name}>
              <Textarea id={name} name={name} defaultValue={value} rows={2} />
            </Field>
          ) : (
            <Item key={name} label={label} value={value} />
          ),
        )}
        {editable && (
          <Button type="submit" variant="outline" className="no-print w-fit">
            <Save /> บันทึกผล
          </Button>
        )}
      </form>
    </Panel>
  )
}

function AssignPanel({ job }: { job: RepairJob }) {
  const { currentUser, profiles, profileName, assignTechnician } = useAppStore()
  const techs = profiles.filter((p) => p.role === 'TECH' && p.active)
  const isAdmin = currentUser?.role === 'ADMIN'
  const closed = job.status === 'COMPLETED' || job.status === 'CANCELLED'

  return (
    <Panel title="ช่างผู้รับผิดชอบ">
      {isAdmin && !closed ? (
        <form
          className="flex flex-col gap-2 sm:flex-row"
          onSubmit={(e) => {
            e.preventDefault()
            const id = String(new FormData(e.currentTarget).get('tech'))
            if (!id) return toast.error('กรุณาเลือกช่าง')
            const res = assignTechnician(job.id, id)
            if (!res.ok) return toast.error(res.error)
            toast.success(`มอบหมายให้ ${profileName(id)} แล้ว`)
          }}
        >
          <select name="tech" aria-label="เลือกช่าง" className="native-select" defaultValue={job.technicianId ?? ''}>
            <option value="">— เลือกช่าง —</option>
            {techs.map((t) => <option key={t.id} value={t.id}>{t.fullName}</option>)}
          </select>
          <Button type="submit" className="h-11 md:h-10">มอบหมาย</Button>
        </form>
      ) : (
        <p className="text-sm">{job.technicianId ? profileName(job.technicianId) : 'ยังไม่มอบหมาย'}</p>
      )}
    </Panel>
  )
}

function StatusDialog({
  job,
  options,
  open,
  onOpenChange,
}: {
  job: RepairJob
  options: JobStatus[]
  open: boolean
  onOpenChange: (v: boolean) => void
}) {
  const { changeStatus } = useAppStore()
  const [to, setTo] = React.useState<JobStatus | ''>('')
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>เปลี่ยนสถานะงาน</DialogTitle>
          <DialogDescription>
            สถานะปัจจุบัน: {STATUS_LABEL[job.status]} — ทุกการเปลี่ยนแปลงจะถูกบันทึกในประวัติพร้อมผู้ดำเนินการและเวลา
          </DialogDescription>
        </DialogHeader>
        <form
          className="grid gap-4"
          onSubmit={(e) => {
            e.preventDefault()
            if (!to) return toast.error('กรุณาเลือกสถานะใหม่')
            const note = String(new FormData(e.currentTarget).get('note') ?? '')
            if (to === 'CANCELLED' && !note.trim()) return toast.error('กรุณาระบุเหตุผลการยกเลิก')
            const res = changeStatus(job.id, to, note || undefined)
            if (!res.ok) return toast.error(res.error)
            toast.success(`เปลี่ยนสถานะเป็น “${STATUS_LABEL[to]}” แล้ว`)
            setTo('')
            onOpenChange(false)
          }}
        >
          <div className="grid gap-2" role="radiogroup" aria-label="สถานะใหม่">
            {options.map((s) => (
              <button
                key={s}
                type="button"
                role="radio"
                aria-checked={to === s}
                onClick={() => setTo(s)}
                className={cn(
                  'flex min-h-11 items-center justify-between rounded-lg border px-3 text-left text-sm transition-colors',
                  to === s ? 'border-highlight bg-accent/40' : 'border-border hover:bg-muted',
                )}
              >
                <StatusBadge status={s} />
                {to === s && <span className="text-xs text-primary">เลือกแล้ว</span>}
              </button>
            ))}
          </div>
          <Field label="หมายเหตุ" htmlFor="status-note" hint={to === 'CANCELLED' ? 'จำเป็นสำหรับการยกเลิก' : undefined}>
            <Textarea id="status-note" name="note" rows={2} />
          </Field>
          <DialogFooter>
            <Button type="submit" size="lg">ยืนยัน</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function IssuePartDialog({
  job,
  open,
  onOpenChange,
}: {
  job: RepairJob
  open: boolean
  onOpenChange: (v: boolean) => void
}) {
  const { inventory, moveStock } = useAppStore()
  const [partId, setPartId] = React.useState('')
  const item = inventory.find((i) => i.id === partId)
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>เบิกอะไหล่สำหรับ <JobNo>{job.jobNo}</JobNo></DialogTitle>
          <DialogDescription>ระบบจะตัดสต๊อกและผูกรายการกับใบงานนี้ เบิกเกินยอดคงเหลือไม่ได้</DialogDescription>
        </DialogHeader>
        <form
          className="grid gap-4"
          onSubmit={(e) => {
            e.preventDefault()
            const qty = Number(new FormData(e.currentTarget).get('qty'))
            const res = moveStock({ partId, type: 'OUT', qty, jobId: job.id })
            if (!res.ok) return toast.error(res.error)
            toast.success(`เบิก ${item?.name} × ${qty} แล้ว คงเหลือ ${res.value.balanceAfter}`)
            setPartId('')
            onOpenChange(false)
          }}
        >
          <Field label="อะไหล่" htmlFor="issue-part">
            <select id="issue-part" className="native-select" value={partId} onChange={(e) => setPartId(e.target.value)} required>
              <option value="">— เลือกอะไหล่ —</option>
              {inventory.map((i) => (
                <option key={i.id} value={i.id} disabled={i.onHand === 0}>
                  {i.code} · {i.name} (คงเหลือ {i.onHand})
                </option>
              ))}
            </select>
          </Field>
          <Field label="จำนวน" htmlFor="issue-qty" hint={item ? `คงเหลือ ${item.onHand} ${item.unit}` : undefined}>
            <Input id="issue-qty" name="qty" type="number" min={1} max={item?.onHand} defaultValue={1} inputMode="numeric" className="h-11" required />
          </Field>
          <DialogFooter>
            <Button type="submit" size="lg" disabled={!partId}>ยืนยันการเบิก</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
