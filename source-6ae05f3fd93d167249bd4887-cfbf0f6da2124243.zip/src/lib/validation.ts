// Client-side checks for account forms. The server repeats every check.

export type AccountErrors = Partial<Record<'fullName' | 'username' | 'password' | 'confirm' | 'token', string>>

export function validateNewAccount(f: FormData): AccountErrors {
  const e: AccountErrors = {}
  const username = String(f.get('username') ?? '')
  const password = String(f.get('password') ?? '')
  if (String(f.get('fullName') ?? '').trim().length < 2) e.fullName = 'กรุณากรอกชื่อ'
  if (!/^[a-z0-9._-]{3,20}$/.test(username))
    e.username = 'ใช้ a–z, 0–9, จุด, ขีด 3–20 ตัวอักษร'
  return { ...e, ...validatePassword(password, String(f.get('confirm') ?? '')) }
}

export function validatePassword(password: string, confirm: string): AccountErrors {
  const e: AccountErrors = {}
  if (password.length < 10 || !/\d/.test(password) || !/[a-zA-Z]/.test(password))
    e.password = 'อย่างน้อย 10 ตัวอักษร มีทั้งตัวอักษรและตัวเลข'
  if (password !== confirm) e.confirm = 'ยืนยันรหัสผ่านไม่ตรงกัน'
  return e
}
