// In-memory app state for the product surface, seeded from fixtures.ts.
// The action signatures here are the contract later milestones keep: each one
// becomes a server function backed by a database transaction (see PLAN.md).
import * as React from 'react'

import * as fx from './fixtures'
import {
  allowedNextStatuses,
  type Company,
  type InventoryItem,
  type InventoryTx,
  type JobStatus,
  type Profile,
  type RepairJob,
  type Role,
} from './domain'

type Result<T = void> = { ok: true; value: T } | { ok: false; error: string }

type NewJobInput = Omit<
  RepairJob,
  'id' | 'jobNo' | 'receivedAt' | 'history' | 'parts' | 'status' | 'receivedBy'
>

type StockMoveInput = {
  partId: string
  type: 'IN' | 'OUT' | 'ADJUST'
  qty: number // always positive for IN/OUT; signed for ADJUST
  jobId?: string
  reference?: string
  reason?: string
}

type NewUserInput = Omit<Profile, 'id' | 'createdAt'>

type AppStore = {
  currentUser: Profile | null
  company: Company
  profiles: Profile[]
  jobs: RepairJob[]
  inventory: InventoryItem[]
  transactions: InventoryTx[]
  signIn: (username: string) => Result<Profile>
  signOut: () => void
  createJob: (input: NewJobInput) => Result<RepairJob>
  updateJob: (id: string, patch: Partial<RepairJob>) => Result
  changeStatus: (id: string, to: JobStatus, note?: string) => Result
  assignTechnician: (id: string, technicianId: string) => Result
  moveStock: (input: StockMoveInput) => Result<InventoryTx>
  reverseTx: (txId: string, reason: string) => Result
  saveItem: (item: Omit<InventoryItem, 'id'> & { id?: string }) => Result
  createUser: (input: NewUserInput) => Result<Profile>
  updateUser: (id: string, patch: Partial<Profile>) => Result
  updateCompany: (c: Company) => Result
  profileName: (id?: string) => string
}

const Ctx = React.createContext<AppStore | null>(null)

const uid = () => Math.random().toString(36).slice(2, 10)
const nowIso = () => new Date().toISOString()
const fail = (error: string) => ({ ok: false as const, error })

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = React.useState<Profile | null>(null)
  const [company, setCompany] = React.useState(fx.company)
  const [profiles, setProfiles] = React.useState(fx.profiles)
  const [jobs, setJobs] = React.useState(fx.jobs)
  const [inventory, setInventory] = React.useState(fx.inventory)
  const [transactions, setTransactions] = React.useState(fx.transactions)

  const role: Role | undefined = currentUser?.role

  const store: AppStore = {
    currentUser,
    company,
    profiles,
    jobs,
    inventory,
    transactions,

    signIn(username) {
      const p = profiles.find(
        (x) => x.username.toLowerCase() === username.trim().toLowerCase(),
      )
      if (!p) return fail('ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง')
      if (!p.active) return fail('บัญชีนี้ถูกระงับการใช้งาน กรุณาติดต่อผู้ดูแลระบบ')
      setCurrentUser(p)
      return { ok: true, value: p }
    },

    signOut() {
      setCurrentUser(null)
    },

    createJob(input) {
      if (!currentUser || role === 'TECH') return fail('ไม่มีสิทธิ์รับแจ้งงาน')
      const d = new Date()
      const prefix = `HS-${String(d.getFullYear()).slice(2)}${String(d.getMonth() + 1).padStart(2, '0')}-`
      const seq =
        Math.max(
          0,
          ...jobs
            .filter((j) => j.jobNo.startsWith(prefix))
            .map((j) => Number(j.jobNo.slice(prefix.length))),
        ) + 1
      const at = nowIso()
      const status: JobStatus = input.technicianId ? 'ASSIGNED' : 'WAITING_ASSIGN'
      const job: RepairJob = {
        ...input,
        id: uid(),
        jobNo: prefix + String(seq).padStart(4, '0'),
        receivedAt: at,
        receivedBy: currentUser.id,
        status,
        parts: [],
        history: [
          { id: uid(), at, by: currentUser.id, from: null, to: 'RECEIVED' },
          { id: uid(), at, by: currentUser.id, from: 'RECEIVED', to: status },
        ],
      }
      setJobs((js) => [job, ...js])
      return { ok: true, value: job }
    },

    updateJob(id, patch) {
      if (!currentUser) return fail('กรุณาเข้าสู่ระบบ')
      const job = jobs.find((j) => j.id === id)
      if (!job) return fail('ไม่พบใบงาน')
      if (role === 'TECH' && job.technicianId !== currentUser.id)
        return fail('แก้ไขได้เฉพาะงานที่ได้รับมอบหมาย')
      if (role !== 'ADMIN' && 'technicianId' in patch)
        return fail('เฉพาะผู้ดูแลระบบที่มอบหมายช่างได้')
      setJobs((js) => js.map((j) => (j.id === id ? { ...j, ...patch } : j)))
      return { ok: true, value: undefined }
    },

    changeStatus(id, to, note) {
      if (!currentUser || !role) return fail('กรุณาเข้าสู่ระบบ')
      const job = jobs.find((j) => j.id === id)
      if (!job) return fail('ไม่พบใบงาน')
      if (role === 'TECH' && job.technicianId !== currentUser.id)
        return fail('เปลี่ยนสถานะได้เฉพาะงานที่ได้รับมอบหมาย')
      if (!allowedNextStatuses(job.status, role).includes(to))
        return fail('ไม่สามารถเปลี่ยนเป็นสถานะนี้ได้')
      if (to === 'ASSIGNED' && !job.technicianId)
        return fail('กรุณาเลือกช่างผู้รับผิดชอบก่อน')
      const entry = { id: uid(), at: nowIso(), by: currentUser.id, from: job.status, to, note }
      setJobs((js) =>
        js.map((j) =>
          j.id === id ? { ...j, status: to, history: [...j.history, entry] } : j,
        ),
      )
      return { ok: true, value: undefined }
    },

    assignTechnician(id, technicianId) {
      if (role !== 'ADMIN' || !currentUser) return fail('เฉพาะผู้ดูแลระบบที่มอบหมายช่างได้')
      const job = jobs.find((j) => j.id === id)
      const tech = profiles.find((p) => p.id === technicianId && p.role === 'TECH' && p.active)
      if (!job) return fail('ไม่พบใบงาน')
      if (!tech) return fail('ไม่พบช่างที่เลือก หรือบัญชีถูกระงับ')
      const moveToAssigned = job.status === 'RECEIVED' || job.status === 'WAITING_ASSIGN'
      const entry = {
        id: uid(), at: nowIso(), by: currentUser.id, from: job.status,
        to: moveToAssigned ? ('ASSIGNED' as const) : job.status,
        note: `มอบหมายให้ ${tech.fullName}`,
      }
      setJobs((js) =>
        js.map((j) =>
          j.id === id
            ? { ...j, technicianId, status: entry.to, history: [...j.history, entry] }
            : j,
        ),
      )
      return { ok: true, value: undefined }
    },

    moveStock({ partId, type, qty, jobId, reference, reason }) {
      if (!currentUser || !role) return fail('กรุณาเข้าสู่ระบบ')
      if (role === 'FRONT') return fail('ไม่มีสิทธิ์จัดการสต๊อก')
      if (role === 'TECH' && type !== 'OUT') return fail('ช่างเบิกอะไหล่ได้เท่านั้น')
      if (role === 'TECH' && !jobId) return fail('กรุณาระบุใบงานที่เบิกอะไหล่')
      const item = inventory.find((i) => i.id === partId)
      if (!item) return fail('ไม่พบอะไหล่')
      if (!Number.isInteger(qty) || qty === 0) return fail('จำนวนไม่ถูกต้อง')
      if (type === 'ADJUST' && !reason?.trim()) return fail('กรุณาระบุเหตุผลการปรับยอด')
      const delta = type === 'IN' ? Math.abs(qty) : type === 'OUT' ? -Math.abs(qty) : qty
      const balanceAfter = item.onHand + delta
      if (balanceAfter < 0)
        return fail(`ยอดคงเหลือไม่พอ (คงเหลือ ${item.onHand} ${item.unit})`)
      const tx: InventoryTx = {
        id: uid(), at: nowIso(), type, partId, qty: delta, balanceAfter,
        by: currentUser.id, jobId, reference, reason,
      }
      setInventory((xs) => xs.map((i) => (i.id === partId ? { ...i, onHand: balanceAfter } : i)))
      setTransactions((ts) => [tx, ...ts])
      if (type === 'OUT' && jobId)
        setJobs((js) =>
          js.map((j) =>
            j.id === jobId
              ? { ...j, parts: [...j.parts, { partId, qty: -delta, at: tx.at, by: currentUser.id }] }
              : j,
          ),
        )
      return { ok: true, value: tx }
    },

    reverseTx(txId, reason) {
      if (role !== 'ADMIN') return fail('เฉพาะผู้ดูแลระบบที่ย้อนรายการได้')
      const tx = transactions.find((t) => t.id === txId)
      if (!tx) return fail('ไม่พบรายการ')
      if (tx.type === 'REVERSAL' || transactions.some((t) => t.reversesId === txId))
        return fail('รายการนี้ถูกย้อนแล้ว')
      const item = inventory.find((i) => i.id === tx.partId)!
      const balanceAfter = item.onHand - tx.qty
      if (balanceAfter < 0) return fail('ย้อนรายการไม่ได้ ยอดคงเหลือจะติดลบ')
      const rev: InventoryTx = {
        id: uid(), at: nowIso(), type: 'REVERSAL', partId: tx.partId, qty: -tx.qty,
        balanceAfter, by: currentUser!.id, jobId: tx.jobId, reason, reversesId: tx.id,
      }
      setInventory((xs) => xs.map((i) => (i.id === tx.partId ? { ...i, onHand: balanceAfter } : i)))
      setTransactions((ts) => [rev, ...ts])
      return { ok: true, value: undefined }
    },

    saveItem(item) {
      if (role !== 'ADMIN') return fail('เฉพาะผู้ดูแลระบบที่แก้ไขข้อมูลอะไหล่ได้')
      if (inventory.some((i) => i.code === item.code && i.id !== item.id))
        return fail('รหัสอะไหล่นี้มีอยู่แล้ว')
      if (item.id) {
        // On-hand quantity only changes through transactions
        setInventory((xs) =>
          xs.map((i) => (i.id === item.id ? { ...i, ...item, onHand: i.onHand } : i)),
        )
      } else {
        setInventory((xs) => [...xs, { ...item, id: uid(), onHand: 0 }])
      }
      return { ok: true, value: undefined }
    },

    createUser(input) {
      if (role !== 'ADMIN') return fail('เฉพาะผู้ดูแลระบบที่เพิ่มผู้ใช้งานได้')
      if (profiles.some((p) => p.username === input.username))
        return fail('ชื่อผู้ใช้นี้ถูกใช้แล้ว')
      const p: Profile = { ...input, id: uid(), createdAt: nowIso() }
      setProfiles((ps) => [...ps, p])
      return { ok: true, value: p }
    },

    updateUser(id, patch) {
      if (role !== 'ADMIN') return fail('เฉพาะผู้ดูแลระบบที่แก้ไขผู้ใช้งานได้')
      if (id === currentUser?.id && (patch.role || patch.active === false))
        return fail('ไม่สามารถเปลี่ยนบทบาทหรือระงับบัญชีของตัวเองได้')
      setProfiles((ps) => ps.map((p) => (p.id === id ? { ...p, ...patch } : p)))
      return { ok: true, value: undefined }
    },

    updateCompany(c) {
      if (role !== 'ADMIN') return fail('เฉพาะผู้ดูแลระบบที่แก้ไขข้อมูลบริษัทได้')
      setCompany(c)
      return { ok: true, value: undefined }
    },

    profileName(id) {
      return profiles.find((p) => p.id === id)?.fullName ?? '—'
    },
  }

  return <Ctx.Provider value={store}>{children}</Ctx.Provider>
}

export function useAppStore() {
  const s = React.useContext(Ctx)
  if (!s) throw new Error('useAppStore must be used inside AppStoreProvider')
  return s
}
