// Shared domain vocabulary: roles, job statuses, allowed transitions, labels.
// These rules are mirrored server-side in a later milestone (see PLAN.md);
// the UI uses them only to decide what to show.

export type Role = 'ADMIN' | 'FRONT' | 'TECH'

export const ROLE_LABEL: Record<Role, string> = {
  ADMIN: 'ผู้ดูแลระบบ',
  FRONT: 'พนักงานหน้าร้าน',
  TECH: 'ช่างซ่อม',
}

export type JobStatus =
  | 'RECEIVED'
  | 'WAITING_ASSIGN'
  | 'ASSIGNED'
  | 'IN_PROGRESS'
  | 'WAITING_PARTS'
  | 'WAITING_APPROVAL'
  | 'COMPLETED'
  | 'CANCELLED'

export const STATUS_ORDER: JobStatus[] = [
  'RECEIVED',
  'WAITING_ASSIGN',
  'ASSIGNED',
  'IN_PROGRESS',
  'WAITING_PARTS',
  'WAITING_APPROVAL',
  'COMPLETED',
  'CANCELLED',
]

export const STATUS_LABEL: Record<JobStatus, string> = {
  RECEIVED: 'รับแจ้งงาน',
  WAITING_ASSIGN: 'รอมอบหมายช่าง',
  ASSIGNED: 'มอบหมายช่างแล้ว',
  IN_PROGRESS: 'กำลังดำเนินการ',
  WAITING_PARTS: 'รออะไหล่',
  WAITING_APPROVAL: 'รออนุมัติ',
  COMPLETED: 'ซ่อมสำเร็จ',
  CANCELLED: 'ยกเลิกงาน',
}

/** Tailwind classes for the status pill. */
export const STATUS_TONE: Record<JobStatus, string> = {
  RECEIVED: 'bg-secondary text-secondary-foreground',
  WAITING_ASSIGN: 'bg-warn/20 text-foreground ring-1 ring-warn/50',
  ASSIGNED: 'bg-accent text-accent-foreground',
  IN_PROGRESS: 'bg-highlight/20 text-primary ring-1 ring-highlight/50',
  WAITING_PARTS: 'bg-warn/30 text-foreground',
  WAITING_APPROVAL: 'bg-primary/10 text-primary',
  COMPLETED: 'bg-ok/15 text-foreground ring-1 ring-ok/40',
  CANCELLED: 'bg-muted text-muted-foreground line-through',
}

export const TRANSITIONS: Record<JobStatus, JobStatus[]> = {
  RECEIVED: ['WAITING_ASSIGN', 'ASSIGNED', 'CANCELLED'],
  WAITING_ASSIGN: ['ASSIGNED', 'CANCELLED'],
  ASSIGNED: ['IN_PROGRESS', 'WAITING_ASSIGN', 'CANCELLED'],
  IN_PROGRESS: ['WAITING_PARTS', 'WAITING_APPROVAL', 'COMPLETED', 'CANCELLED'],
  WAITING_PARTS: ['IN_PROGRESS', 'CANCELLED'],
  WAITING_APPROVAL: ['IN_PROGRESS', 'COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
}

/** Statuses a TECH may move a job into (only on jobs assigned to them). */
export const TECH_ALLOWED: JobStatus[] = [
  'IN_PROGRESS',
  'WAITING_PARTS',
  'WAITING_APPROVAL',
  'COMPLETED',
]

export function allowedNextStatuses(
  from: JobStatus,
  role: Role,
): JobStatus[] {
  const next = TRANSITIONS[from]
  if (role === 'ADMIN') return next
  if (role === 'TECH') return next.filter((s) => TECH_ALLOWED.includes(s))
  // FRONT handles intake only
  return next.filter((s) => s === 'WAITING_ASSIGN' || s === 'CANCELLED')
}

export const OPEN_STATUSES: JobStatus[] = [
  'RECEIVED',
  'WAITING_ASSIGN',
  'ASSIGNED',
  'IN_PROGRESS',
  'WAITING_PARTS',
  'WAITING_APPROVAL',
]

export type Urgency = 'LOW' | 'NORMAL' | 'HIGH' | 'URGENT'

export const URGENCY_LABEL: Record<Urgency, string> = {
  LOW: 'ไม่เร่งด่วน',
  NORMAL: 'ปกติ',
  HIGH: 'ด่วน',
  URGENT: 'ด่วนมาก',
}

export const MACHINE_TYPES = [
  'ฝาบน',
  'ฝาหน้า',
  '2 ถัง',
  'เครื่องซักอุตสาหกรรม',
  'เครื่องซักหยอดเหรียญ',
  'เครื่องอบผ้า',
] as const

export type Profile = {
  id: string
  fullName: string
  username: string
  role: Role
  active: boolean
  phone?: string
  createdAt: string
}

export type Company = {
  nameTh: string
  nameEn: string
  address: string
  phones: string
  taxId?: string
}

export type JobHistory = {
  id: string
  at: string
  by: string
  from: JobStatus | null
  to: JobStatus
  note?: string
}

export type JobPart = {
  partId: string
  qty: number
  at: string
  by: string
}

export type RepairJob = {
  id: string
  jobNo: string
  receivedAt: string
  customerName: string
  phone: string
  contactName?: string
  address: string
  machineType: string
  brand: string
  model: string
  serialNo?: string
  symptom: string
  details?: string
  receivedBy: string
  technicianId?: string
  appointmentAt?: string
  urgency: Urgency
  status: JobStatus
  note?: string
  diagnosis?: string
  resolution?: string
  result?: string
  photos: number
  history: JobHistory[]
  parts: JobPart[]
}

export type InventoryItem = {
  id: string
  code: string
  name: string
  category: string
  compatible: string
  unit: string
  onHand: number
  minQty: number
  cost: number
  location: string
  note?: string
}

export type TxType = 'IN' | 'OUT' | 'ADJUST' | 'REVERSAL'

export const TX_LABEL: Record<TxType, string> = {
  IN: 'รับเข้า',
  OUT: 'เบิกออก',
  ADJUST: 'ปรับยอด',
  REVERSAL: 'ย้อนรายการ',
}

export type InventoryTx = {
  id: string
  at: string
  type: TxType
  partId: string
  qty: number // signed: + adds stock, - removes stock
  balanceAfter: number
  by: string
  jobId?: string
  reference?: string
  reason?: string
  reversesId?: string
}

export function isOverdue(job: RepairJob, now = new Date()): boolean {
  return (
    !!job.appointmentAt &&
    OPEN_STATUSES.includes(job.status) &&
    new Date(job.appointmentAt) < now
  )
}

const dateFmt = new Intl.DateTimeFormat('th-TH', {
  day: 'numeric',
  month: 'short',
  year: '2-digit',
  timeZone: 'Asia/Bangkok',
})
const dateTimeFmt = new Intl.DateTimeFormat('th-TH', {
  day: 'numeric',
  month: 'short',
  year: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
  timeZone: 'Asia/Bangkok',
})

export const fmtDate = (iso?: string) => (iso ? dateFmt.format(new Date(iso)) : '—')
export const fmtDateTime = (iso?: string) =>
  iso ? dateTimeFmt.format(new Date(iso)) : '—'
export const fmtBaht = (n: number) =>
  n.toLocaleString('th-TH', { style: 'currency', currency: 'THB' })
