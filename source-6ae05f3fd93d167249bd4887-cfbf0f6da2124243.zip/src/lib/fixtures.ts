// Stub data for the product surface. Every screen reads through `useAppStore`
// (src/lib/store.tsx), which is seeded from this file. Replacing this module
// with real database queries is milestone 2 in PLAN.md.

import type {
  Company,
  InventoryItem,
  InventoryTx,
  Profile,
  RepairJob,
} from './domain'

export const company: Company = {
  nameTh: 'บริษัท หาดใหญ่ซาวด์สตาร์ จำกัด',
  nameEn: 'Hatyai Soundstar Co., Ltd.',
  address: '123 ถนนเพชรเกษม อ.หาดใหญ่ จ.สงขลา 90110',
  phones: '074-123-456, 081-999-8888',
}

export const profiles: Profile[] = [
  { id: 'u1', fullName: 'สมชาย ใจดี', username: 'admin01', role: 'ADMIN', active: true, phone: '081-111-2222', createdAt: '2026-09-01T09:00:00+07:00' },
  { id: 'u2', fullName: 'กมลวรรณ ศรีสุข', username: 'front01', role: 'FRONT', active: true, phone: '089-222-3333', createdAt: '2026-09-02T10:15:00+07:00' },
  { id: 'u3', fullName: 'อนุชา แก้วมณี', username: 'tech01', role: 'TECH', active: true, phone: '086-333-4444', createdAt: '2026-09-02T10:20:00+07:00' },
  { id: 'u4', fullName: 'ธีรพงษ์ หมัดหลี', username: 'tech02', role: 'TECH', active: true, phone: '087-444-5555', createdAt: '2026-09-05T13:40:00+07:00' },
  { id: 'u5', fullName: 'ปิยะนุช ทองคำ', username: 'front02', role: 'FRONT', active: false, createdAt: '2026-09-10T08:30:00+07:00' },
]

export const inventory: InventoryItem[] = [
  { id: 'p1', code: 'MTR-DD-01', name: 'มอเตอร์ไดเรกต์ไดรฟ์', category: 'มอเตอร์', compatible: 'LG ฝาหน้า 8–10 กก.', unit: 'ตัว', onHand: 2, minQty: 2, cost: 3450, location: 'ชั้น A-1' },
  { id: 'p2', code: 'PMP-DR-02', name: 'ปั๊มน้ำทิ้ง', category: 'ปั๊ม', compatible: 'Samsung / LG / Electrolux', unit: 'ตัว', onHand: 7, minQty: 4, cost: 520, location: 'ชั้น A-3' },
  { id: 'p3', code: 'BLT-V-14', name: 'สายพาน V-Belt 14"', category: 'สายพาน', compatible: 'Toshiba, Hitachi 2 ถัง', unit: 'เส้น', onHand: 1, minQty: 5, cost: 85, location: 'ลิ้นชัก B-2' },
  { id: 'p4', code: 'VLV-IN-01', name: 'วาล์วน้ำเข้า 2 ทาง', category: 'วาล์ว', compatible: 'ทุกยี่ห้อ ฝาบน', unit: 'ตัว', onHand: 12, minQty: 6, cost: 240, location: 'ชั้น A-2' },
  { id: 'p5', code: 'PCB-SS-07', name: 'บอร์ดควบคุม WA-Series', category: 'แผงวงจร', compatible: 'Samsung WA10–WA14', unit: 'แผ่น', onHand: 0, minQty: 1, cost: 2890, location: 'ตู้ล็อก C-1' },
  { id: 'p6', code: 'DLK-FL-03', name: 'สวิตช์ล็อกประตู', category: 'สวิตช์', compatible: 'Electrolux / Beko ฝาหน้า', unit: 'ตัว', onHand: 5, minQty: 3, cost: 380, location: 'ลิ้นชัก B-4' },
  { id: 'p7', code: 'BRG-6205', name: 'ลูกปืน 6205 + ซีล', category: 'ลูกปืน', compatible: 'ฝาหน้าทั่วไป', unit: 'ชุด', onHand: 3, minQty: 4, cost: 310, location: 'ลิ้นชัก B-1' },
  { id: 'p8', code: 'CAP-12UF', name: 'คาปาซิเตอร์ 12µF', category: 'ไฟฟ้า', compatible: '2 ถัง / ฝาบน', unit: 'ตัว', onHand: 18, minQty: 8, cost: 65, location: 'ลิ้นชัก B-3' },
]

export const jobs: RepairJob[] = [
  {
    id: 'j1', jobNo: 'HS-2610-0042', receivedAt: '2026-10-27T08:42:00+07:00',
    customerName: 'ร้านซักรีดเพชรเกษม', phone: '074-235-118', contactName: 'คุณวิภา',
    address: '45/2 ถ.เพชรเกษม ซ.8 หาดใหญ่', machineType: 'เครื่องซักหยอดเหรียญ',
    brand: 'LG', model: 'FH0C3QDNG', serialNo: '702KWQX1234', symptom: 'เครื่องไม่ปั่นหมาด มีเสียงดังที่ถัง',
    details: 'ลูกค้าแจ้งว่าเป็นมา 3 วัน ใช้งานวันละ 12 รอบ', receivedBy: 'u2', urgency: 'URGENT',
    status: 'WAITING_ASSIGN', appointmentAt: '2026-10-27T14:00:00+07:00', photos: 3,
    history: [
      { id: 'h1', at: '2026-10-27T08:42:00+07:00', by: 'u2', from: null, to: 'RECEIVED', note: 'รับแจ้งทางโทรศัพท์' },
      { id: 'h2', at: '2026-10-27T08:50:00+07:00', by: 'u2', from: 'RECEIVED', to: 'WAITING_ASSIGN' },
    ],
    parts: [],
  },
  {
    id: 'j2', jobNo: 'HS-2610-0041', receivedAt: '2026-10-26T15:10:00+07:00',
    customerName: 'นายประเสริฐ บุญมา', phone: '081-765-4321', address: '88 หมู่ 3 ต.คอหงส์ อ.หาดใหญ่',
    machineType: 'ฝาบน', brand: 'Samsung', model: 'WA12T5260BY', symptom: 'เปิดไม่ติด หน้าจอไม่ขึ้น',
    receivedBy: 'u2', technicianId: 'u3', urgency: 'NORMAL', status: 'WAITING_PARTS',
    appointmentAt: '2026-10-26T10:00:00+07:00', photos: 2,
    diagnosis: 'บอร์ดควบคุมเสีย ไฟไม่เข้าวงจรหลัก', note: 'สั่งบอร์ดจากศูนย์แล้ว รอ 3–5 วัน',
    history: [
      { id: 'h3', at: '2026-10-26T15:10:00+07:00', by: 'u2', from: null, to: 'RECEIVED' },
      { id: 'h4', at: '2026-10-26T15:30:00+07:00', by: 'u1', from: 'RECEIVED', to: 'ASSIGNED', note: 'มอบหมายให้ช่างอนุชา' },
      { id: 'h5', at: '2026-10-26T16:45:00+07:00', by: 'u3', from: 'ASSIGNED', to: 'IN_PROGRESS' },
      { id: 'h6', at: '2026-10-26T17:20:00+07:00', by: 'u3', from: 'IN_PROGRESS', to: 'WAITING_PARTS', note: 'บอร์ด PCB-SS-07 หมดสต๊อก' },
    ],
    parts: [],
  },
  {
    id: 'j3', jobNo: 'HS-2610-0040', receivedAt: '2026-10-25T10:05:00+07:00',
    customerName: 'หอพักสุขสันต์', phone: '089-456-7788', contactName: 'คุณเอก',
    address: '12 ถ.ธรรมนูญวิถี หาดใหญ่', machineType: 'ฝาหน้า', brand: 'Electrolux', model: 'EWF8025CQWA',
    symptom: 'ประตูล็อกไม่ได้ เครื่องไม่เริ่มทำงาน', receivedBy: 'u2', technicianId: 'u4', urgency: 'HIGH',
    status: 'IN_PROGRESS', appointmentAt: '2026-10-27T10:30:00+07:00', photos: 1,
    diagnosis: 'สวิตช์ล็อกประตูขาด', history: [
      { id: 'h7', at: '2026-10-25T10:05:00+07:00', by: 'u2', from: null, to: 'RECEIVED' },
      { id: 'h8', at: '2026-10-25T11:00:00+07:00', by: 'u1', from: 'RECEIVED', to: 'ASSIGNED' },
      { id: 'h9', at: '2026-10-27T09:10:00+07:00', by: 'u4', from: 'ASSIGNED', to: 'IN_PROGRESS' },
    ],
    parts: [{ partId: 'p6', qty: 1, at: '2026-10-27T09:25:00+07:00', by: 'u4' }],
  },
  {
    id: 'j4', jobNo: 'HS-2610-0039', receivedAt: '2026-10-24T13:20:00+07:00',
    customerName: 'นางสาวอรทัย จันทร์แก้ว', phone: '086-112-3344', address: '9/14 หมู่บ้านพฤกษา ต.ควนลัง',
    machineType: '2 ถัง', brand: 'Toshiba', model: 'VH-H140WT', symptom: 'ถังปั่นไม่หมุน',
    receivedBy: 'u2', technicianId: 'u3', urgency: 'LOW', status: 'COMPLETED', photos: 4,
    diagnosis: 'สายพานขาด คาปาซิเตอร์เสื่อม', resolution: 'เปลี่ยนสายพานและคาปาซิเตอร์', result: 'ทดสอบปั่น 3 รอบ ปกติ',
    history: [
      { id: 'h10', at: '2026-10-24T13:20:00+07:00', by: 'u2', from: null, to: 'RECEIVED' },
      { id: 'h11', at: '2026-10-24T13:40:00+07:00', by: 'u1', from: 'RECEIVED', to: 'ASSIGNED' },
      { id: 'h12', at: '2026-10-25T09:00:00+07:00', by: 'u3', from: 'ASSIGNED', to: 'IN_PROGRESS' },
      { id: 'h13', at: '2026-10-25T11:30:00+07:00', by: 'u3', from: 'IN_PROGRESS', to: 'COMPLETED', note: 'ลูกค้ารับทราบและชำระเงินแล้ว' },
    ],
    parts: [
      { partId: 'p3', qty: 1, at: '2026-10-25T10:10:00+07:00', by: 'u3' },
      { partId: 'p8', qty: 1, at: '2026-10-25T10:12:00+07:00', by: 'u3' },
    ],
  },
  {
    id: 'j5', jobNo: 'HS-2610-0038', receivedAt: '2026-10-23T09:00:00+07:00',
    customerName: 'โรงแรมลีการ์เด้นส์', phone: '074-261-111', contactName: 'แผนกแม่บ้าน',
    address: '29 ถ.ประชาธิปัตย์ หาดใหญ่', machineType: 'เครื่องซักอุตสาหกรรม', brand: 'Electrolux', model: 'WH6-14',
    symptom: 'น้ำไม่ระบาย ขึ้น Error E20', receivedBy: 'u1', technicianId: 'u4', urgency: 'HIGH',
    status: 'WAITING_APPROVAL', appointmentAt: '2026-10-24T09:00:00+07:00', photos: 2,
    diagnosis: 'ปั๊มน้ำทิ้งตัน ใบพัดแตก', note: 'เสนอราคาเปลี่ยนปั๊ม รอลูกค้าอนุมัติ',
    history: [
      { id: 'h14', at: '2026-10-23T09:00:00+07:00', by: 'u1', from: null, to: 'RECEIVED' },
      { id: 'h15', at: '2026-10-23T09:05:00+07:00', by: 'u1', from: 'RECEIVED', to: 'ASSIGNED' },
      { id: 'h16', at: '2026-10-24T10:00:00+07:00', by: 'u4', from: 'ASSIGNED', to: 'IN_PROGRESS' },
      { id: 'h17', at: '2026-10-24T11:15:00+07:00', by: 'u4', from: 'IN_PROGRESS', to: 'WAITING_APPROVAL' },
    ],
    parts: [],
  },
  {
    id: 'j6', jobNo: 'HS-2610-0037', receivedAt: '2026-10-22T16:40:00+07:00',
    customerName: 'นายสมศักดิ์ แซ่ลิ้ม', phone: '084-998-1122', address: '301 ถ.นิพัทธ์อุทิศ 3',
    machineType: 'ฝาบน', brand: 'Hitachi', model: 'SF-150ZFV', symptom: 'น้ำไม่เข้าเครื่อง',
    receivedBy: 'u2', urgency: 'NORMAL', status: 'CANCELLED', photos: 0,
    history: [
      { id: 'h18', at: '2026-10-22T16:40:00+07:00', by: 'u2', from: null, to: 'RECEIVED' },
      { id: 'h19', at: '2026-10-23T08:30:00+07:00', by: 'u2', from: 'RECEIVED', to: 'CANCELLED', note: 'ลูกค้าแจ้งยกเลิก ซื้อเครื่องใหม่' },
    ],
    parts: [],
  },
]

export const transactions: InventoryTx[] = [
  { id: 't1', at: '2026-10-20T09:00:00+07:00', type: 'IN', partId: 'p4', qty: 10, balanceAfter: 12, by: 'u1', reference: 'PO-2610-011' },
  { id: 't2', at: '2026-10-20T09:05:00+07:00', type: 'IN', partId: 'p8', qty: 10, balanceAfter: 20, by: 'u1', reference: 'PO-2610-011' },
  { id: 't3', at: '2026-10-25T10:10:00+07:00', type: 'OUT', partId: 'p3', qty: -1, balanceAfter: 1, by: 'u3', jobId: 'j4' },
  { id: 't4', at: '2026-10-25T10:12:00+07:00', type: 'OUT', partId: 'p8', qty: -1, balanceAfter: 19, by: 'u3', jobId: 'j4' },
  { id: 't5', at: '2026-10-26T14:00:00+07:00', type: 'ADJUST', partId: 'p8', qty: -1, balanceAfter: 18, by: 'u1', reason: 'นับสต๊อกประจำเดือน พบชำรุด 1 ตัว' },
  { id: 't6', at: '2026-10-27T09:25:00+07:00', type: 'OUT', partId: 'p6', qty: -1, balanceAfter: 5, by: 'u4', jobId: 'j3' },
]
